create
    definer = root@localhost procedure GreetWorld()
select concat(@gretting, 'world');

